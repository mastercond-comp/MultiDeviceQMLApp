#include <auroraapp.h>
#include <QtQuick>

#include <QScreen>
#include <QtCore/qmath.h>
#include <QDebug>

int main(int argc, char *argv[])
{
    QScopedPointer<QGuiApplication> application(Aurora::Application::application(argc, argv));
    application->setOrganizationName(QStringLiteral("ru.auroraos"));
    application->setApplicationName(QStringLiteral("MultiDeviceQMLApp"));

    QScopedPointer<QQuickView> view(Aurora::Application::createView());


    //СЕКЦИЯ ПОЛУЧЕНИЯ РАЗМЕРА ДИАГОНАЛИ ЭКРАНА УСТРОЙСТВА АВРОРА (после определения QGuiApplication)

    QScreen *screen=QGuiApplication::primaryScreen();
    qreal devicescreen_height=screen->physicalSize().rheight();
    qreal devicescreen_width=screen->physicalSize().rwidth();
    qreal screen_diagonal=qSqrt(devicescreen_height*devicescreen_height+devicescreen_width*devicescreen_width)/25.4; //размер диагонали экрана в дюймах

    qDebug() << "Физический размер экрана устройства: "+QString::number(screen_diagonal); //для R570E получилось 5.51097

    //КОНЕЦ СЕКЦИИ ПОЛУЧЕНИЯ РАЗМЕРА ДИАГОНАЛИ ЭКРАНА УСТРОЙСТВА АВРОРА

    if (screen_diagonal<7) {
    view->setSource(Aurora::Application::pathTo(QStringLiteral("qml/MultiDeviceQMLApp_phone.qml")));
    }
    else
    {
         view->setSource(Aurora::Application::pathTo(QStringLiteral("qml/MultiDeviceQMLApp_tablet.qml")));
    }

    view->show();

    return application->exec();
}
